import { EventEmitter, Injectable, Output } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Post } from '../models/post.model';
import { map } from 'rxjs/operators';
import { UserService } from 'src/app/services/user.service';
import {Token} from '../models/token.model';
import jwt_decode from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http: HttpClient, private userSvc: UserService) { }

  GetAllPosts() {
    return this.http.get<Post[]>(`${environment.BASE_URL}/Posts/`).pipe(map((data) => {
      data.forEach(c => c.createdDate = new Date(c.createdDate));
      data.sort((a,b) => {
        let result = 0;
        if (a.createdDate > b.createdDate){
          result = -1;
        }
        else if (a.createdDate > b.createdDate){
          result = 1;
        }
        else{
          result = 0;
        }
        return result;
      });
    } ));
  }

  CreatePost(post: Post): Observable<Post>

  {

    const currentUser = this.userSvc.GetLoggedInUser();

    return this.http.post<Post>(`${environment.BASE_URL}/Posts`, post, {headers: new HttpHeaders().set('Authorization', `Bearer ${currentUser.token}`)});

  }

  Delete(post: Post): Observable<any>

  {

    const currentUser = this.userSvc.GetLoggedInUser();

    return this.http.delete(`${environment.BASE_URL}/Posts/${post.postId}`, {headers: new HttpHeaders().set('Authorization', `Bearer ${currentUser.token}`)});

  }

  GetPost(postId: number): Observable<any>

  {

    const currentUser = this.userSvc.GetLoggedInUser();

    return this.http.get<Post>(`${environment.BASE_URL}/Posts/${postId}`, {headers: new HttpHeaders().set('Authorization', `Bearer ${currentUser.token}`)});

  }

  UpdatePost(post: Post): Observable<Post>

  {

    const currentUser = this.userSvc.GetLoggedInUser();

    return this.http.patch<Post>(`${environment.BASE_URL}/Posts/${post.postId}`, post, {headers: new HttpHeaders().set('Authorization', `Bearer ${currentUser.token}`)});

  }
}
