export class postOutput {
    postId: number = 0;
    createDate = '';
    title = '';
    content = '';
    userId = '';
    headerImage = '';
    lastUpdated = '';
  
  }
  