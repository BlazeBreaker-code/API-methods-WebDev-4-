/* export class Post {
    title = '';
    content = '';
    headerImage = '';
  } */
  export class Post {
    postId: number = 0;
    createdDate = new Date;
    title = '';
    content = '';
    userId = '';
    headerImage = '';
    lastUpdated = '';
  
  }
  
  