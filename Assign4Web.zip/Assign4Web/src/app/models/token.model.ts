import { User } from './user.model';


export class Token {
  token = '';
  UserData: User;
  iat: number;
  exp: number;
  sub: string;

}
