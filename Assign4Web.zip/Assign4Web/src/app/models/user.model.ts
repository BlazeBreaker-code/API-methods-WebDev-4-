export class User {
  userId = '';
  firstName = '';
  lastName = '';
  emailAddress = '';
  password = '';

}
