import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private userSvc: UserService, private router: Router) { }
  currentUser = '';
  ngOnInit(): void {
    this.userSvc.UserStateChanged.subscribe((userLoggedIn) => {
      if (!userLoggedIn){
        this.router.navigate(['/login', {newusermsg: `You have successfully logged out`}]);
      }
    });
    this.currentUser = this.userSvc.GetLoggedInUser().UserData.firstName;
  }

}
