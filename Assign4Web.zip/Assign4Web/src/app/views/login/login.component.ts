import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userId = '';
  password = '';
  errMsg = '';
  successMessage = '';
  constructor(private router: Router, private userSvc: UserService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.successMessage = this.route.snapshot.paramMap.get('newusermsg');
    this.userId = this.route.snapshot.paramMap.get('userId');
  }

  LoginUser(): void
  {
    if (this.userId === ''){
      this.errMsg = 'User id is Required';
    }
    else if (this.password === '')
    {
      this.errMsg = 'Password is required';
    }
    else
    {
      this.userSvc.LogIn(this.userId, this.password).subscribe(response => {

        this.userSvc.SetLoggedInUser(response.token);
        this.router.navigate(['/home']);
      }, err => {
        this.errMsg = err.error.messsage;
      });
    }

  }
}
