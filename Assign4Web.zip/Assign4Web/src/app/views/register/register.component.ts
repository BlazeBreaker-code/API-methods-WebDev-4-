import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: User = new User();
  errMsg = '';
  constructor(private router: Router, private userSvc: UserService) { }

  ngOnInit(): void {
  }

  CreateUser(): void {
    this.userSvc.CreateNewUser(this.user).subscribe((newUserResponses) => {
      console.log(newUserResponses);
      this.errMsg = '';
      // tslint:disable-next-line: max-line-length
      this.router.navigate(['/login', {newusermsg: `User account created successfully for user: ${this.user.userId} please login below`, userId: this.user.userId }]);
    }, (error) => {
      this.errMsg = error.error.messsage;
    });
  }

}
