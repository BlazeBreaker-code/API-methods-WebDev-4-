import { Component, OnInit } from '@angular/core';
import { Post } from 'src/app/models/post.model';
import { Router } from '@angular/router';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-new-post',
  templateUrl: './new-post.component.html',
  styleUrls: ['./new-post.component.css']
})
export class NewPostComponent implements OnInit {
//Shout out to Prof Jose and Farrah and Arfan for helping 
  post: Post;
  content: string = '';
  title: string = '';
  headerImage: string = '';
  errMsg = '';
  constructor(private router: Router, private postSvc: PostService) { }

  ngOnInit(): void {
    this.post = new Post();
  }

  NewPost() {
    this.post.content = this.content;
    this.post.title = this.title;
    this.post.headerImage = this.headerImage;
    this.postSvc.CreatePost(this.post).subscribe((newPostResponse) => {
      console.log(newPostResponse);
      this.errMsg = '';
      this.router.navigate(['/']);
        }, 
        (error) => {
      this.errMsg = error.error.messsage;
    });
  }
}
