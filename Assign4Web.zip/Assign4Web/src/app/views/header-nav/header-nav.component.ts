
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { faSignInAlt, faSignOutAlt, faUserPlus } from '@fortawesome/free-solid-svg-icons';
import { Token } from 'src/app/models/token.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-header-nav',
  templateUrl: './header-nav.component.html',
  styleUrls: ['./header-nav.component.css']
})
export class HeaderNavComponent implements OnInit {
  faSignInAlt = faSignInAlt;
  faSignOutAlt = faSignOutAlt;
  faUserPlus  = faUserPlus;
  userLoggedIn = false;
  loggedInUserInfo: Token = null;
  constructor(private router: Router, private userSvc: UserService) {


      this.userLoggedIn = (this.loggedInUserInfo = this.userSvc.GetLoggedInUser()) !== null;

      this.userSvc.UserStateChanged.subscribe((userLoggedIn) => {
        this.userLoggedIn = userLoggedIn;
        this.loggedInUserInfo = this.userSvc.GetLoggedInUser();
      });

   }

  ngOnInit(): void {
  }

  LogOutUser(): void
  {
    this.userSvc.LogOutUser();
  }

}
